import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.css']
})
export class BarComponent implements OnInit {

  // constructor() { }

  ngOnInit() {
  }

  constructor() {

    this.options = {
      title : {text : 'Time in Range'},
    
      chart : { type: "column",
                
                //zoomType : 'x'
              },

      subtitle: {
        text: 'PAST 2 WEEKS'
    },

  //   xAxis: {
  //     categories: [
  //         '12AM',
  //         '3AM',
  //         '6AM',
  //         '9AM',
  //         '12PM',
  //         '3PM',
  //         '6PM',
  //         '9PM',
  //         '12AM'
  //     ],
  //     crosshair: true
  // },

  // yAxis: {
  //     min: 0,
  //     title: {
  //         text: 'Rainfall (mm)'
  //     }
  // },
  yAxis : {
    min: 0,
    title: {
       text: 'Population (millions)',
       align: 'high'
    },
    labels: {
       overflow: 'justify'
    }
 },

  //Series name block alignment
  legend: {
    align: 'right',
    x: -30,
    verticalAlign: 'top',
    y: 25,
    floating: true,
   // backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
    borderColor: '#CCC',
    borderWidth: 1,
    shadow: false
  },

  tooltip: {
    pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
    shared: true
    },
    plotOptions: {
        column: {
            stacking: 'percent'
        },
        series: {
          dataLabels: {
            enabled: true,
            align: 'right',
            //format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
           // format: '<b>{point.name}</b>{point.percentage:.1f}%',
            color: '#000000',
            x: 40,
            filter: {
              property: 'percentage',
              operator: '>',
              value: 4
          }
          },
          pointWidth: 40,
          pointPadding: 0.1,
          groupPadding: 0
      }
    },

     credits : {
      enabled: false
    },
    
    //   series : [{ 
    //     name: 'Tokyo', 
    //    // data: [20.7,88.8,222.4,154.2,50.17,120], 
    //   //  data: [
    //   //       {
    //   //           name: "a",
    //   //           y: 100
    //   //       },
    //   //       {
    //   //           name: "b",
    //   //           y: 20
    //   //       },
    //   //       {
    //   //           name: "c",
    //   //           y: 50
    //   //       }
    //   //   ]

    // //  data: [5, 3, 4, 7, 2],   
    //   }]

    series: [{
      name: '4',
      //data: [5]
      data : [{ y: 4 ,color: '#354db4', }],
      
  }, {
      name: '71',
      //data: [3]
      data : [{ y: 71 , color: '#28c7a1', }],
      
  }, {
      name: '10',
      //data: [4]
      data : [{ y: 10 , color: '#ff7702', }],
      
  }, {
    name: '2',
    //data: [4]
    data : [{ y: 2 ,color: '#d93951',   }],
   
}

]
    
      };

  }

 options:object;

}
